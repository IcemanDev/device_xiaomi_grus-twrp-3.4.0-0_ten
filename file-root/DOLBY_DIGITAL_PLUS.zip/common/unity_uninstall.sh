if ! $MAGISK || $SYSOVERRIDE; then
  for OFILE in ${CFGS}; do
    FILE="$UNITY$(echo $OFILE | sed "s|^/vendor|/system/vendor|g")"
    case $FILE in
      *.conf) sed -i "/dsplus { #$MODID/,/} #$MODID/d" $FILE;;
      *.xml) sed -i "/<!--$MODID-->/d" $FILE;;
    esac
  done
  if [ -f /system_root/sbin/restart.bak ]; then
	mount -o rw,remount /system_root
	mv -f /system_root/sbin/restart.bak /system_root/sbin/restart.sh
  fi
  if [ -f /system_root/system/*/MusicFX/MusicFX.bak ]; then
    MUSICFXbak="$(find /system_root/system | grep -i MusicFX.bak | sed 's/ /ftemps/g' 2>/dev/null)";
	mount -o rw,remount /system_root
    mount -o rw,remount /system_root/system
	MUSICFXapkMOD="$(find $MUSICFXbak | cut -d"." -f1 2>/dev/null)"
	mv -f $MUSICFXbak $MUSICFXapkMOD.apk
  fi
fi
